#!/bin/bash

for ((i=0; i<10; i++)); do
	if [ $i -lt 5 ]; then
        	continue;
	fi
	echo $i
done
