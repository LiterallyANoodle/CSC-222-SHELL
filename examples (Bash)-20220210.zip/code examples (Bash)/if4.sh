#!/bin/bash

b=3
read -p "Enter your first grade: " q1
read -p "Enter your second grade: " q2

if [[ "$q1" -ge 10 && "$q2" -ge 10 ]] ; then
    echo You don\'t need a bonus

else
    echo You get a bonus of "$b"
fi


