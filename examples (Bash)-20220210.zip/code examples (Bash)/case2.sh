#!/bin/bash

echo "Are you hungry? "
read belly

case $belly in
	y | yes | Y | YES) echo "Go eat some grub!";;
	[nN]*) echo "I am!";;
	*) echo "I don't understand...";;
esac
