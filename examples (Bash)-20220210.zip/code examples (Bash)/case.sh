#!/bin/bash

echo Are you hungry? 
read belly

case $belly in
	y | yes) echo "Go eat some grub!";;
	n | no) echo "I am!";;
	*) echo "I don't understand...";;
esac
