#!/bin/bash

# this is comment
: '
comment
more comments
....
'
read fname lname
echo your name firstname: $name 
echo your lastname: $lname


