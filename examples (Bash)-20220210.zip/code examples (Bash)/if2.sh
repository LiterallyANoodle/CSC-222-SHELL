#!/bin/bash

if test -f $1 ; then
    echo First argument is a file

elif [ -d "$1" ]
then
    echo First argument is directory with the following content
    ls -l $1

else
    echo First argument is neither a file nor a directory 
fi


