#!/bin/bash

# this is comment
: '
comment
more comments
....
'
name=2 # spaces are important 
echo 'In single quotes name is $name'


echo "In double quotes name is $name"

