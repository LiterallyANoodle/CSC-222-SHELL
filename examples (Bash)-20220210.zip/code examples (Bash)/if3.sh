#!/bin/bash

read -p "Enter your grade: " grade
if [ ! $grade -lt 100 ] ; then
    echo You pass the class

else
    echo You need to do more 
fi


