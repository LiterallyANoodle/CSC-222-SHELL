#!/bin/bash

# this is comment
: '
comment
more comments
....
'
read name
echo your name is $name


read -p "Enter your name:" name
echo "your name is $name"

