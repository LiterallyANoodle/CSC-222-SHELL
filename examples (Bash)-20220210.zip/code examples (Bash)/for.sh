#!/bin/bash

#uncomment as needed
for f in a1 b2 c3 1.5 2 thedraw $@
do
	echo $f
done

#for file in $(ls *.sh); do
#	wc -l $file
#done

#for foo in 1 2 3 4 5; do
#for foo in {1..5}; do
#	echo horseface
#done

#for ((i=0; i<10; i++)); do
#	echo $i
#done
