#!/bin/bash
var=hello

foo()
{
    local var=world
	echo $var
}

echo $var
foo
echo $var
