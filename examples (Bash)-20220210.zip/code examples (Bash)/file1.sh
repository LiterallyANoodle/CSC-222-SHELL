#!/bin/bash

read -p "Enter a filename: " filename

if [  -r "$filename" ] ; then
    echo The file "$file" has a read access

else
    echo Can\'t read the content of this file
fi


