#!/bin/bash
foo()
{
	echo "Is your name $* (y/n)? "
	while true; do
		read ans

		case $ans in
			y) return 0;;
			n) return 1;;
			*) echo -n "I said (y/n)... ";;
		esac
	done
}
echo "Original parameters are: $*"
if foo $1
then
	echo Hi, $1!
else
	echo "Never mind..."
fi
