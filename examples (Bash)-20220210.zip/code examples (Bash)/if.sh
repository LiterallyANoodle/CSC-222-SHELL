#!/bin/bash

if [ $1 -lt 100 ] ; then
    echo First argument is less than 100
    date
elif [ $1 -gt 100 ]
then
    echo First argument is greater than 100

else
    echo In Else: First argument is equal to 100
fi


