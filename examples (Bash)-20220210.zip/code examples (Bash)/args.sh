#!/bin/bash

# this is comment


echo "The name of this script: $0"
echo "The list of all arguments: $@"
echo "Another way of showing all arguments: $*" 
echo "PID of the current process: $$"

