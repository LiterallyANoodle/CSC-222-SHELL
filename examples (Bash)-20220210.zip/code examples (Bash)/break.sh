#!/bin/bash

for ((i=0; i<10; i++)); do
	echo $i
	if [ $i -gt 5 ]; then
        	break;
	fi
done
