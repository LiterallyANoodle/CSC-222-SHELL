#!/bin/bash


var=hello

foo()
{
        var=world
	echo $var
}

echo $var
foo
echo $var
