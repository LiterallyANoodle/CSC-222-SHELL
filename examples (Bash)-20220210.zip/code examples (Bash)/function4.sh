#!/bin/bash

foo()
{
	while [ $1 ]; do
		echo "param: $1"
		shift
	done
}

foo a b c 1 2 3
printf "%s is %d years old.\n" "Malcolm" 4
